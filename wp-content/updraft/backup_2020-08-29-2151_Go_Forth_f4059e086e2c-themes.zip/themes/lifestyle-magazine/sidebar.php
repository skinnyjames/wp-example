<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Lifestyle Magazine
 */
?>

<div id="secondary" class="widget-area" role="complementary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div><!-- #secondary -->