<?php if ( is_active_sidebar( 'woocommerce_sidebar' ) ) : ?>
    <?php dynamic_sidebar( 'woocommerce_sidebar' ); ?>
<?php endif;